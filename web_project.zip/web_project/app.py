from flask import Flask, render_template, request, jsonify, send_from_directory
import cv2
import numpy as np
import base64
import os

app = Flask(__name__, static_folder='static')

def compute_integral_image(img):
    img = img.astype(np.float32)
    integral_img = np.zeros((img.shape[0] + 1, img.shape[1] + 1), dtype=np.float32)
    for x in range(1, integral_img.shape[0]):
        for y in range(1, integral_img.shape[1]):
            integral_img[x, y] = img[x-1, y-1] + integral_img[x-1, y] + integral_img[x, y-1] - integral_img[x-1, y-1]
    return integral_img[1:, 1:]

def image_stitch(images):
    sift = cv2.SIFT_create()
    keypoints_all = []
    descriptors_all = []
    for img in images:
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        keypoints, descriptors = sift.detectAndCompute(gray, None)
        keypoints_all.append(keypoints)
        descriptors_all.append(descriptors)

    FLANN_INDEX_KDTREE = 1
    index_params = dict(algorithm=FLANN_INDEX_KDTREE, trees=5)
    search_params = dict(checks=50)
    flann = cv2.FlannBasedMatcher(index_params, search_params)

    matches_all = []
    for i in range(len(images) - 1):
        matches = flann.knnMatch(descriptors_all[i], descriptors_all[i + 1], k=2)
        good_matches = [m for m, n in matches if m.distance < 0.7 * n.distance]
        matches_all.append(good_matches)

    homographies = []
    for i, matches in enumerate(matches_all):
        src_pts = np.float32([keypoints_all[i][m.queryIdx].pt for m in matches]).reshape(-1, 1, 2)
        dst_pts = np.float32([keypoints_all[i + 1][m.trainIdx].pt for m in matches]).reshape(-1, 1, 2)
        H, _ = cv2.findHomography(src_pts, dst_pts, cv2.RANSAC, 5.0)
        homographies.append(H)

    height, width = images[0].shape[:2]
    panorama = cv2.warpPerspective(images[0], homographies[0], (width, height))
    for i, H in enumerate(homographies[1:]):
        panorama = cv2.warpPerspective(panorama, H, (width, height))

    return panorama

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/calculate-integral', methods=['POST'])
def calculate_integral():
    file = request.files['image']
    npimg = np.frombuffer(file.read(), np.uint8)
    img = cv2.imdecode(npimg, cv2.IMREAD_GRAYSCALE)
    integral_image = compute_integral_image(img)
    cv2.imwrite('static/integral_image.jpg', integral_image)
    return jsonify({'url': '/static/integral_image.jpg'})

@app.route('/stitch-images', methods=['POST'])
def stitch_images():
    files = request.files.getlist('images')
    images = [cv2.imdecode(np.frombuffer(file.read(), np.uint8), cv2.IMREAD_COLOR) for file in files]
    panorama = image_stitch(images)
    filename = 'panorama.jpg'
    cv2.imwrite(os.path.join(app.static_folder, filename), panorama)
    return jsonify({'url': f'/static/{filename}'})

if __name__ == '__main__':
    app.run(debug=True)
