let canvas, ctx, points = [];

window.onload = function() {
    canvas = document.getElementById('imageCanvas');
    ctx = canvas.getContext('2d');
    document.getElementById('imageUploadSingle').addEventListener('change', function(event) {
        handleImageUpload(event, function(img) {
            resetCanvas(img);
        });
    });
    document.getElementById('imageUploadMultiple').addEventListener('change', function(event) {
        handleMultipleImageUpload(event);
    });
};

function handleImageUpload(event, callback) {
    let reader = new FileReader();
    reader.onload = function() {
        let img = new Image();
        img.onload = function() {
            callback(img);
        };
        img.src = reader.result;
    };
    reader.readAsDataURL(event.target.files[0]);
}

function resetCanvas(img) {
    canvas.width = img.width;
    canvas.height = img.height;
    ctx.drawImage(img, 0, 0);
    points = [];
}

canvas.addEventListener('click', function(event) {
    if (points.length < 2) {
        points.push([event.offsetX, event.offsetY]);
        ctx.fillStyle = 'red';
        ctx.beginPath();
        ctx.arc(event.offsetX, event.offsetY, 5, 0, 2 * Math.PI);
        ctx.fill();
    }
});

function sendData() {
    if (points.length === 2) {
        canvas.toBlob(function(blob) {
            let reader = new FileReader();
            reader.onloadend = function() {
                $.ajax({
                    url: '/calculate',
                    method: 'POST',
                    contentType: 'application/json',
                    data: JSON.stringify({
                        image: reader.result,
                        points: points
                    }),
                    success: function(response) {
                        document.getElementById('dimensionDisplay').textContent = 'Dimensions: ' + response.dimensions.toFixed(2) + ' mm';
                    }
                });
            };
            reader.readAsDataURL(blob);
        });
    } else {
        alert('Please select exactly two points on the image.');
    }
}

function handleMultipleImageUpload(event) {
    let files = event.target.files;
    let images = [];
    Array.from(files).forEach(file => {
        let reader = new FileReader();
        reader.onload = function (e) {
            images.push(e.target.result);
            if (images.length === files.length) {
                sendStitchRequest(images);
            }
        };
        reader.readAsDataURL(file);
    });
}

function sendStitchRequest(images) {
    $.ajax({
        url: '/stitch',
        method: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({images: images}),
        success: function(response) {
            document.getElementById('resultDisplay').src = response.panoramic_image;
        }
    });
}

function refreshCanvas() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    document.getElementById('imageUploadSingle').value = '';
    document.getElementById('dimensionDisplay').textContent = '';
}

function refreshStitcher() {
    document.getElementById('imageUploadMultiple').value = '';
    document.getElementById('resultDisplay').src = '';
}
